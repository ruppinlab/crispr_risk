####sgRNA off-target effects
################################################################
##Load libraries
################################################################
require(parallel)
require(tictoc)
require(CRISPRseek)
library(BSgenome.Hsapiens.UCSC.hg19)
library(TxDb.Hsapiens.UCSC.hg19.knownGene)
library(org.Hs.eg.db)
# if (!requireNamespace("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
# BiocManager::install("CRISPRseek")
# BiocManager::install("BSgenome.Hsapiens.UCSC.hg19")
# BiocManager::install("TxDb.Hsapiens.UCSC.hg19.knownGene")
# BiocManager::install("org.Hs.eg.db")
################################################################
##Load Files
################################################################
# setwd("/data/sinhas8/Project_CRISPR/2.Data/offtarget_data/")
# outputDir <- getwd()
# inputFilePath <- '/Users/sinhas8/Project_CRISPR/2.Data/offtarget_data/sgRNA_sequences_avana_foroffTarget_scores.fa'
# REpatternFile <- system.file('extdata', 'NEBenzymes.fa', package = 'CRISPRseek')
# gRNAFilePath <- system.file('extdata', 'testHsap_GATA1_ex2_gRNA1.fa', package = 'CRISPRseek')
setwd("/data/sinhas8/Proj_CRISPR_OffTarget")
outputDir <- getwd()
inputFilePath <- 'sgRNA_sequences_avana_foroffTarget_scores.fa'
REpatternFile <- system.file('extdata', 'NEBenzymes.fa', package = 'CRISPRseek')
gRNAFilePath <- system.file('extdata', 'testHsap_GATA1_ex2_gRNA1.fa', package = 'CRISPRseek')
################################################################
##Run Func
################################################################
tic()
results1 <- offTargetAnalysis(inputFilePath = inputFilePath,
                             findgRNAsWithREcutOnly = FALSE,
                             #REpatternFile = REpatternFile,
                             findPairedgRNAOnly = FALSE,
                             findgRNAs = FALSE,
                             BSgenomeName = Hsapiens,
                             #chromToSearch = 'chrX',
                             txdb = TxDb.Hsapiens.UCSC.hg19.knownGene,
                             orgAnn = org.Hs.egSYMBOL,
                             max.mismatch = 1, 
                             outputDir = outputDir, 
                             overwrite = TRUE,
                             enable.multicore=TRUE,
                             n.cores.max=detectCores(),
                             annotateExon = T,
                             topN.OfftargetTotalScore=10,
                             fetchSequence=F
                             # ,scoring.method='CFDscore'
                             )
toc()
saveRDS(results1, 'results1_v2_withtop10_onlyMismatchPosition_oneMismatchAllowed.RDS')


###
# setwd('/Users/sinhas8/Project_CRISPR/2.Data')
# offTarg_v2=readRDS('results1_v2.RDS')
# dim(offTarg_v2$on.target)

# Get Off-TargetScore - Feb 19th
# sftp sinhas8@biowulf.nih.gov
# cd /data/sinhas8/Proj_CRISPR_OffTarget
# ls -l
# lpwd
# lcd /Users/sinhas8/Project_CRISPR/2.Data
# get results1_v2_withtop10_onlyMismatchPosition_oneMismatchAllowed.RDS

