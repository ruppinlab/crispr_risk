subset_pathway=hallmark_genes[c(1, 8, 37, 48, 49)]
POI=names(hallmark_genes[c(1, 8, 37, 48, 49)])
exp_FC=(exp_cas9/exp_Parental)
differential_signature_wtvsMut<-function(geneName='KRAS', pathway_id=1){
  kras_mut=matched_mutmatrix[geneName, match(colnames(exp_cas9),
                                           CCLE_cellLineName)]
  names(kras_mut)=colnames(exp_cas9)
  mutant_lines=names(which(kras_mut==1))
  WT_lines=names(which(kras_mut==0))
  # Mut vs WT
  inMutated_CellLines=sapply(mutant_lines, function(x)
    err_handle(enriched_pathway(geneList = annotation$Gene_Symbol,
                     score = exp_FC[,x],
                     pathways_list = subset_pathway[pathway_id])))
  inWT_CellLines=sapply(WT_lines, function(x)
    err_handle(enriched_pathway(geneList = annotation$Gene_Symbol,
                                score = exp_FC[,x],
                                pathways_list = subset_pathway[pathway_id])))
  list(inMutated_CellLines, inWT_CellLines)
}
kras_test1=differential_signature_wtvsMut(geneName = 'KRAS', pathway_id = 1)
names(kras_test1)=c('inMutated_CellLines', 'inWT_CellLines')
inmut=as.numeric(fdrcorr(unlist(kras_test1$inMutated_CellLines[2,]))<0.1 & 
                   unlist(kras_test1$inMutated_CellLines[4,])>0)
inWT=as.numeric(fdrcorr(unlist(kras_test1$inWT_CellLines[2,]))<0.1 & 
                  unlist(kras_test1$inWT_CellLines[4,])>0)
sum(inmut)/length(inmut)
sum(inWT)/length(inWT)
sig= fisher.test(matrix(c(table(inmut), table(inWT))[c(1, 3, 2, 4)], 2, 2), 
                 alternative = 'g')

nfb=rbind(data.frame(Status='Mutated',
                     sig=unlist(inMutated_CellLines[2,]),
                     ES=unlist(inMutated_CellLines[4,])),
          data.frame(Status='WT',
                     sig=unlist(inWT_CellLines[2,]),
                     ES=unlist(inWT_CellLines[4,])))
list(sig, hits=list(inmut, inWT), nfb)

