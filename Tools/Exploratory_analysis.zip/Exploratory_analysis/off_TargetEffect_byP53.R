########################################################################
##Off target effect by p53:: Preprocessing
########################################################################
source('/Users/sinhas8/Project_CRISPR/Project_CRISPR.Risk_Github/Tools/Step0_Globally_used_Functions_and_Datasets.R')
require(ggplot2); require(parallel)
setwd('/Users/sinhas8/Project_CRISPR/2.Data')
offTarget=readRDS('results1_v2.RDS')
offTarget_Score=offTarget$summary[,c(1, 6, 7)]
offTarget_Score$GeneNames=sapply(as.character(offTarget_Score[,1]), function(x) strsplit(x, '\\.')[[1]][1])
Mean_OffTarg_Score=sapply(split(offTarget_Score[,2:3], offTarget_Score$GeneNames), function(x) colMeans(x, na.rm = T))
Mean_OffTarg_Score=t(Mean_OffTarg_Score)

CDE=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/CDE_allThree.csv')
p53.CDEpos=as.character(unlist(CDE$p53.CDE.))[as.character(unlist(CDE$p53.CDE.))!='']
p53.CDEneg=as.character(unlist(CDE$p53.CDE..1))[as.character(unlist(CDE$p53.CDE..1))!='']
kras.CDEpos=as.character(unlist(CDE$KRAS.CDE.))[as.character(unlist(CDE$KRAS.CDE.))!='']
kras.CDEneg=as.character(unlist(CDE$KRAS.CDE..1))[as.character(unlist(CDE$KRAS.CDE..1))!='']
vhl.CDEpos=as.character(unlist(CDE$VHL.CDE.))[as.character(unlist(CDE$VHL.CDE.))!='']
vhl.CDEneg=as.character(unlist(CDE$VHL.CDE..1))[as.character(unlist(CDE$VHL.CDE..1))!='']
########################################################################
##Association with TP53
########################################################################
COI=Reduce(intersect, list(colnames(onTarget$avana),
                           colnames(onTarget$mutations_matrix),
                           colnames(onTarget$achilles)))
GOI=Reduce(intersect, list(rownames(onTarget$avana), rownames(onTarget$mutations_matrix), rownames(onTarget$achilles)))

EffectSize_byMasterREgulator<-function(MR='TP53', 
                                       infunc_mat=onTarget$avana[GOI, COI],
                                       Mut=onTarget$mutations_matrix[GOI, COI]){
    do.call(rbind, mclapply(1:nrow(infunc_mat),
                          function(x) c(wilcox.test(unlist(infunc_mat[x,])~unlist(Mut[MR,]))$p.value,
                                        median(unlist(infunc_mat[x,unlist(Mut[MR,])==0]), na.rm = T) -
                                          median(unlist(infunc_mat[x,unlist(Mut[MR,])==1]), na.rm = T) ),
                          mc.cores = detectCores() ) )
}
p53_effect=EffectSize_byMasterREgulator('TP53')
KRAS_effect=EffectSize_byMasterREgulator('KRAS')
# VHL_effect=EffectSize_byMasterREgulator('VHL')
rownames(p53_effect)=GOI
rownames(KRAS_effect)=GOI
# rownames(VHL_effect)=GOI

## For shRA effect SIze
p53_effect_shRNA=EffectSize_byMasterREgulator('TP53', infunc_mat = onTarget$achilles[GOI, COI])
KRAS_effect_shRNA=EffectSize_byMasterREgulator('KRAS', infunc_mat = onTarget$achilles[GOI, COI])
VHL_effect_shRNA=EffectSize_byMasterREgulator('VHL', infunc_mat = onTarget$achilles[GOI, COI])

###
Mean_OffTarg_Score_matched=Mean_OffTarg_Score[match(GOI, rownames(Mean_OffTarg_Score)),]
head(p53_effect); head(Mean_OffTarg_Score_matched)
Mean_OffTarg_Score_matched[head(order(Mean_OffTarg_Score_matched[,2], decreasing = T), 1000),]
range(Mean_OffTarg_Score_matched[,2], na.rm = T)
Mean_OffTarg_Score_matched_ordered=Mean_OffTarg_Score_matched[order(Mean_OffTarg_Score_matched[,2], decreasing = T),]
########################################################################
##Off_Target effect on Essentiality
########################################################################
require(ppcor)
length(p53_effect_shRNA[,2])
df2test=data.frame(x=Mean_OffTarg_Score_matched[,2],
                   y=p53_effect[,2],
                   z=p53_effect_shRNA[,2],
                   )
df2test=na.omit(df2test)
pcor.test(df2test$x,
          df2test$y,
          df2test$z,
          method = c('spearman'))
cor.test(df2test$x,
          df2test$y,
          method = c('spearman'))
########################################################################
##$$$Non-Coding Off_Target effect on Essentiality$$$
########################################################################
########################################################################
#####Different types of Off-Target Effects
####**Only Run this when R si restarted**##
########################################################################

All_offtargets= offTarg_v2$offtarget[,c(1,8)]
Cod_offtargets= offTarg_v2$offtarget[(offTarg_v2$offtarget$inExon==TRUE | offTarg_v2$offtarget$inIntron==TRUE),c(1,8)]
NonCod_offtargets= offTarg_v2$offtarget[!(offTarg_v2$offtarget$inExon==TRUE | offTarg_v2$offtarget$inIntron==TRUE),c(1,8)]
Exon_offtargets= offTarg_v2$offtarget[(offTarg_v2$offtarget$inExon==TRUE),c(1,8)]
Intron_offtargets= offTarg_v2$offtarget[(offTarg_v2$offtarget$inIntron==TRUE),c(1,8)]
###Different types of Off-Target Effects
Scores_from_regionslist<-function(infunc_offTarg_df=All_offtargets){
  infunc_offTarg_df_Scores=data.frame(Score=do.call(rbind,
                                                    mclapply(split(infunc_offTarg_df$score, as.character(infunc_offTarg_df$name)),
                                                             function(x) sum(as.numeric(as.character(x)), na.rm=T) )))
  infunc_offTarg_df_Scores$GeneNames=sapply(rownames(infunc_offTarg_df_Scores), function(x) strsplit(x, '\\.')[[1]][1])
  Mean_infunc_offTarg_df_Scores=data.frame(score=sapply(split(infunc_offTarg_df_Scores$Score, infunc_offTarg_df_Scores$GeneNames), mean))
  Mean_infunc_offTarg_df_Scores_matched= data.frame(score=Mean_infunc_offTarg_df_Scores[match(rownames(onTarget$avana), rownames(Mean_infunc_offTarg_df_Scores)),])
  rownames(Mean_infunc_offTarg_df_Scores_matched)=rownames(onTarget$avana)
  return(Mean_infunc_offTarg_df_Scores_matched)
}
All_offTarg_meanscore=Scores_from_regionslist(infunc_offTarg_df=All_offtargets)
NC_offTarg_meanscore=Scores_from_regionslist(infunc_offTarg_df=NonCod_offtargets)
Cod_offTarg_meanscore=Scores_from_regionslist(infunc_offTarg_df=Cod_offtargets)
Exon_offTarg_meanscore=Scores_from_regionslist(infunc_offTarg_df=Exon_offtargets)
Intron_offTarg_meanscore=Scores_from_regionslist(infunc_offTarg_df=Intron_offtargets)
########################################################################
##Enrichment for CDE Pos Genes
########################################################################
off_target_score_p53<-function(OT_score = All_offTarg_meanscore,
                               size_p53=length(p53.CDEpos), 
                               size_kras=length(kras.CDEpos),
                               size_vhl=length(vhl.CDEpos)){
  GenelistOT_score_ordered = rownames(OT_score)[order(OT_score$score, decreasing = T)]
  length(match(head(GenelistOT_score_ordered, length(p53.CDEpos)), p53.CDEpos))
  c(hypergeometric_test_for_twolists(test_list = head(GenelistOT_score_ordered, size_p53),
                                   base_list = p53.CDEpos,
                                   global = rownames(onTarget$avana)),
  hypergeometric_test_for_twolists(head(GenelistOT_score_ordered, size_kras),
                                   kras.CDEpos,
                                   global = rownames(onTarget$avana)),
  hypergeometric_test_for_twolists(head(GenelistOT_score_ordered, size_vhl),
                                   vhl.CDEpos,
                                   global = rownames(onTarget$avana)))
}
###
cor.test(All_offTarg_meanscore$score, Cod_offTarg_meanscore$score, method='s')
##Cod, NC, ALL off target score is highly cor-related
off_target_score_p53(OT_score = All_offTarg_meanscore)
off_target_score_p53(OT_score = Cod_offTarg_meanscore)
off_target_score_p53(OT_score = Exon_offTarg_meanscore)
off_target_score_p53(OT_score = Intron_offTarg_meanscore)
########################################################################
##Enrichment for CDE neg Genes
########################################################################
off_target_score_p53_Neg<-function(OT_score = All_offTarg_meanscore,
                               size_p53=length(p53.CDEneg), size_kras=length(kras.CDEneg),
                               size_vhl=length(vhl.CDEneg)){
  GenelistOT_score_ordered = rownames(OT_score)[order(OT_score$score, decreasing = F)]
  print(length(na.omit(match(head(GenelistOT_score_ordered, length(p53.CDEneg)), p53.CDEneg))))
  print(length(na.omit(match(head(GenelistOT_score_ordered, length(kras.CDEneg)), kras.CDEneg))))
  print(length(na.omit(match(head(GenelistOT_score_ordered, length(vhl.CDEneg)), vhl.CDEneg))))
  c(hypergeometric_test_for_twolists(test_list = head(GenelistOT_score_ordered, size_p53),
                                     base_list = p53.CDEneg,
                                     global = rownames(onTarget$avana)),
    hypergeometric_test_for_twolists(head(GenelistOT_score_ordered, size_kras),
                                     kras.CDEneg,
                                     global = rownames(onTarget$avana)),
    hypergeometric_test_for_twolists(head(GenelistOT_score_ordered, size_vhl),
                                     vhl.CDEneg,
                                     global = rownames(onTarget$avana)))
}
###
cor.test(All_offTarg_meanscore$score, Cod_offTarg_meanscore$score, method='s')
# Cod, NC, ALL off target score is highly cor-related
off_target_score_p53_Neg(OT_score = All_offTarg_meanscore)
off_target_score_p53_Neg(OT_score = NC_offTarg_meanscore)
off_target_score_p53_Neg(OT_score = Cod_offTarg_meanscore)
off_target_score_p53_Neg(OT_score = Exon_offTarg_meanscore)
off_target_score_p53_Neg(OT_score = Intron_offTarg_meanscore)
########################################################################
##Corr of p53 effect with Off-Target
########################################################################
unlist(cor.test(All_offTarg_meanscore$score-1, p53_effect[,2], method='s')[c(3,4)])
unlist(cor.test(NC_offTarg_meanscore$score, p53_effect[,2], method='s')[c(3,4)])
unlist(cor.test(Cod_offTarg_meanscore$score, p53_effect[,2], method='s')[c(3,4)])
unlist(cor.test(Exon_offTarg_meanscore$score, p53_effect[,2], method='s')[c(3,4)])
unlist(cor.test(Intron_offTarg_meanscore$score, p53_effect[,2], method='s')[c(3,4)])
########################################################################
##Corr of p53 effect with Off-Target for CDE+ and CDE-ve
########################################################################
p53.CDEpos_id=match(p53.CDEpos, rownames(p53_effect))
p53.CDEneg_id=match(p53.CDEneg, rownames(p53_effect))
unlist(cor.test(NC_offTarg_meanscore$score, p53_effect[,2], method='s')[c(3,4)])
unlist(cor.test(NC_offTarg_meanscore$score[p53.CDEpos_id], p53_effect[p53.CDEpos_id,2], method='s')[c(3,4)])
unlist(cor.test(NC_offTarg_meanscore$score[p53.CDEneg_id], p53_effect[p53.CDEneg_id,2], method='s')[c(3,4)])
########################################################################
##Partial COrr of p53 effect with Off-Target
########################################################################
rev(unlist(pcor.test(All_offTarg_meanscore$score-1, p53_effect[,2], p53_effect_shRNA[,2])[c(1,2)]))
rev(unlist(pcor.test(unlist(NC_offTarg_meanscore$score), p53_effect[,2], p53_effect_shRNA[,2])[c(1,2)]))
rev(unlist(pcor.test(Cod_offTarg_meanscore$score, p53_effect[,2], p53_effect_shRNA[,2])[c(1,2)]))
rev(unlist(pcor.test(Exon_offTarg_meanscore$score, p53_effect[,2], p53_effect_shRNA[,2])[c(1,2)]))
rev(unlist(pcor.test(Intron_offTarg_meanscore$score, p53_effect[,2], p53_effect_shRNA[,2])[c(1,2)]))
########################################################################
##Partial COrr of p53 effect with Off-Target for CDE+ and CDE-ve
########################################################################
p53.CDEpos_id=na.omit(p53.CDEpos_id)
p53.CDEneg_id=na.omit(p53.CDEneg_id)
rev(unlist(pcor.test(df$NC, df$crispr, df$shRNA)[c(1,2)]))
df=data.frame(NC=NC_offTarg_meanscore$score[p53.CDEpos_id],
              crispr=p53_effect[p53.CDEpos_id,2],
              shRNA=p53_effect_shRNA[p53.CDEpos_id,2])
df=na.omit(df)
rev(unlist(pcor.test(df$NC, df$crispr, df$shRNA)[c(1,2)]))
##CDE Negative
df=data.frame(NC=NC_offTarg_meanscore$score[p53.CDEneg_id],
              crispr=p53_effect[p53.CDEneg_id,2],
              shRNA=p53_effect_shRNA[p53.CDEneg_id,2])
df=na.omit(df)
rev(unlist(pcor.test(df$NC, df$crispr, df$shRNA)[c(1,2)]))
########################################################################
##Plot P53 effect when ordered by off-Target
########################################################################
K=3
df2plot=  data.frame(Off_target=Intron_offTarg_meanscore$score,
                     P53_Effect= p53_effect[,2])
df2plot=na.omit(df2plot)
my_comparisons= lapply(1:(K-1), function(x) c(x, x+1))
ggplot(df2plot, aes(y=P53_Effect, x=factor(xtile(Off_target, K)), fill=factor(xtile(Off_target, K)) ))+
  geom_boxplot()+
  stat_compare_means(comparisons = my_comparisons, method.args = list(alternative = "greater"))
########################################################################
##Whether correcting for this improves Fragile Site Enrichment
########################################################################
load('/Users/sinhas8/Project_CRISPR/2.Data/cfs.genes.RData')
enrichment_for_off_target<-function(OT_score = All_offTarg_meanscore, correctforOffTarget=T){
  GenelistOT_score_ordered = rownames(OT_score)[order(OT_score$score, decreasing = T)]
  p53.CDEpos_corrected=p53.CDEpos;
  kras.CDEpos_corrected=kras.CDEpos;
  vhl.CDEpos_corrected=vhl.CDEpos;
  if(correctforOffTarget){
    p53.CDEpos_corrected= p53.CDEpos[!(p53.CDEpos %!in% head(GenelistOT_score_ordered, length(p53.CDEpos)))]
    kras.CDEpos_corrected= kras.CDEpos[!(kras.CDEpos %!in% head(GenelistOT_score_ordered, length(kras.CDEpos)))]
    vhl.CDEpos_corrected= vhl.CDEpos[!(vhl.CDEpos %!in% head(GenelistOT_score_ordered, length(vhl.CDEpos)))]
  }
  print(length(na.omit(match(p53.CDEpos_corrected, cfs.genes$cfs))))
  print(length(na.omit(match(kras.CDEpos_corrected, cfs.genes$cfs))))
  print(length(na.omit(match(vhl.CDEpos_corrected, cfs.genes$cfs))))
  c(hypergeometric_test_for_twolists(test_list = p53.CDEpos_corrected,
                                     base_list = cfs.genes$cfs,
                                     global = rownames(avana)),
    hypergeometric_test_for_twolists(kras.CDEpos_corrected,
                                     cfs.genes$cfs,
                                     global = rownames(avana)),
    hypergeometric_test_for_twolists(vhl.CDEpos,
                                     cfs.genes$cfs,
                                     global = rownames(avana)))

}
enrichment_for_off_target(OT_score = All_offTarg_meanscore, correctforOffTarget=F)
enrichment_for_off_target(OT_score = All_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = NC_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = Cod_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = Exon_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = Intron_offTarg_meanscore, correctforOffTarget=T)
########################################################################
##Extra Section:: Not continous part of this code - Off_Target Effect of CDE-Pos vs CDE-Neutral vs CDE-Neg
########################################################################
p53.CDE_Neutral=rownames(p53_effect)[order(abs(p53_effect[,2]), decreasing = F)]
kras.CDE_Neutral=rownames(KRAS_effect)[order(abs(KRAS_effect[,2]), decreasing = F)]
vhl.CDE_Neutral=rownames(VHL_effect)[order(abs(VHL_effect[,2]), decreasing = F)]
CDE_OT_Score_diff<-function(OT_score=All_offTarg_meanscore){
  df2plot=data.frame(rbind(data.frame(Score=OT_score[p53.CDEpos,'score'], Type='Pos'),
                           data.frame(Score=OT_score[head(p53.CDE_Neutral, length(p53.CDEpos)),'score'],
                                      Type='Neutral'),
                           data.frame(Score=OT_score[p53.CDEneg,'score'], Type='Neg')))
  my_comparisons= list(c('Pos', 'Neutral'), c('Neutral', 'Neg'))
  TukeyHSD(aov(df2plot$Score ~ factor(df2plot$Type)))$'factor(df2plot$Type)'[,c(1,4)]
}
(OT_score=All_offTarg_meanscore)
CDE_OT_Score_diff(OT_score = All_offTarg_meanscore)
CDE_OT_Score_diff(OT_score = NC_offTarg_meanscore)
CDE_OT_Score_diff(OT_score = Cod_offTarg_meanscore)
CDE_OT_Score_diff(OT_score = Exon_offTarg_meanscore)
CDE_OT_Score_diff(OT_score = Intron_offTarg_meanscore)
########################################################################
##Corr with Ess when TP53 is WT
########################################################################
GeneofInterest='TP53'
mean_whenWT=rowMeans(mat[,unlist(Mut[GeneofInterest,]==0)])
mean_whenMut=rowMeans(mat[,unlist(Mut[GeneofInterest,]==1)])

head(order(All_offTarg_meanscore$score, decreasing = T), 1000)
cor.test(mean_whenWT[head(order(All_offTarg_meanscore$score, decreasing = T), 1000)],
         All_offTarg_meanscore$score[head(order(All_offTarg_meanscore$score, decreasing = T), 1000)])
cor.test(mean_whenMut[head(order(All_offTarg_meanscore$score, decreasing = T), 1000)],
         All_offTarg_meanscore$score[head(order(All_offTarg_meanscore$score, decreasing = T), 1000)])
########################################################################
##Corr with Raw sgRNA level-Ess when TP53 is WT vs Mut
########################################################################
########################################################################
##DNA damage pathways
########################################################################
DDR=read.csv('/Users/sinhas8/Downloads/geneset (1).txt', header=T)
FA=read.csv('/Users/sinhas8/Downloads/geneset (2).txt', header=T)
enrichment_for_off_target<-function(OT_score = All_offTarg_meanscore, correctforOffTarget=F,
                                    geneset_list=FA$REACTOME_FANCONI_ANEMIA_PATHWAY){
  GenelistOT_score_ordered = rownames(OT_score)[order(OT_score$score, decreasing = T)]
  p53.CDEpos_corrected=p53.CDEpos;
  kras.CDEpos_corrected=kras.CDEpos;
  vhl.CDEpos_corrected=vhl.CDEpos;
  if(correctforOffTarget){
    p53.CDEpos_corrected= p53.CDEpos[!(p53.CDEpos %in% head(GenelistOT_score_ordered, length(p53.CDEpos)))]
    kras.CDEpos_corrected= kras.CDEpos[!(kras.CDEpos %in% head(GenelistOT_score_ordered, length(kras.CDEpos)))]
    vhl.CDEpos_corrected= vhl.CDEpos[sum(vhl.CDEpos %in% head(GenelistOT_score_ordered, length(vhl.CDEpos)))]
  }
  c(hypergeometric_test_for_twolists(test_list = p53.CDEpos_corrected,
                                     base_list = geneset_list,
                                     global = rownames(avana)),
    hypergeometric_test_for_twolists(kras.CDEpos_corrected,
                                     geneset_list,
                                     global = rownames(avana)),
    hypergeometric_test_for_twolists(vhl.CDEpos,
                                     geneset_list,
                                     global = rownames(avana)))

}
enrichment_for_off_target(OT_score = All_offTarg_meanscore, correctforOffTarget=F)
enrichment_for_off_target(OT_score = All_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = NC_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = Cod_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = Exon_offTarg_meanscore, correctforOffTarget=T)
enrichment_for_off_target(OT_score = Intron_offTarg_meanscore, correctforOffTarget=T)

########################################################################
##Only consider sgRNAs where Cod Score =0
########################################################################
summary(Cod_offTarg_meanscore$score)
thresh=0.2
geneSpacetoTest=which(Cod_offTarg_meanscore-1 < thresh)
# geneSpacetoTest=1:nrow(avana)
#geneSpacetoTest=head(order(NC_offTarg_meanscore$score, decreasing = T),1000)
# geneSpacetoTest=c(geneSpacetoTest, head(order(NC_offTarg_meanscore$score, decreasing = T), 100))
# whenWT=sapply(which(unlist(Mut_matched2genedep['KRAS',])==0), function(x)
#        cor.test(NC_offTarg_meanscore[geneSpacetoTest,], genedep[,x][geneSpacetoTest])$estimate)
# whenMut=sapply(which(unlist(Mut_matched2genedep['KRAS',])==1), function(x)
#               cor.test(NC_offTarg_meanscore[geneSpacetoTest,], genedep[,x][geneSpacetoTest])$estimate)
# wilcox.test(whenWT, whenMut, alternative='g')$p.value
#
# whenWT=sapply(which(unlist(Mut['KRAS',])==0), function(x)
#   cor.test(NC_offTarg_meanscore[geneSpacetoTest,], mat[,x][geneSpacetoTest])$estimate)
# whenMut=sapply(which(unlist(Mut['KRAS',])==1), function(x)
#   cor.test(NC_offTarg_meanscore[geneSpacetoTest,], mat[,x][geneSpacetoTest])$estimate)
# wilcox.test(whenWT, whenMut, alternative='l')$p.value
whenWT=sapply(all_WT, function(x)
  cor.test(NC_offTarg_meanscore[geneSpacetoTest,], mat[,x][geneSpacetoTest])$estimate)
whenMut=sapply(two_Mut, function(x)
  cor.test(NC_offTarg_meanscore[geneSpacetoTest,], mat[,x][geneSpacetoTest])$estimate)
wilcox.test(whenWT, whenMut, alternative='l')$p.value
######All three mutants combined
all_WT=which(unlist(Mut['VHL',])==0 & unlist(Mut['TP53',])==0 & unlist(Mut['KRAS',])==0)
two_Mut=which((as.numeric(unlist(Mut['VHL',])==1) + as.numeric(unlist(Mut['TP53',])==1) + as.numeric(unlist(Mut['KRAS',])==1))>1)
head(offTarg_v2$summary)

# Plot the significance of enrichment 
Enrichment_withOnlyPosition = -log(off_target_score_p53(OT_score =
                                                          NC_offTarg_meanscore), 10)
Enrichment_withBothPositionandType = -log(off_target_score_p53(OT_score =
                                                          NC_offTarg_meanscore), 10)
df2plot1=data.frame(MasterRegulator=c('P53', 'KRAS', 'VHL'),
                    log10Sig=Enrichment_withOnlyPosition,
                    Mode='Mismatch Position')
df2plot2=data.frame(MasterRegulator=c('P53', 'KRAS', 'VHL'),
                    log10Sig=Enrichment_withBothPositionandType,
                    Mode='Deep Mismatch \n Position & Type')

df2plot=rbind(df2plot1, df2plot2)
tiff('/Users/sinhas8/Downloads/OffTarget_Enrichement.tiff', width=600)
ggplot(df2plot, aes(x=reorder(MasterRegulator,log10Sig ,function(x) -median(x)), y=log10Sig))+
  geom_bar(stat = "identity")+
  facet_wrap(.~Mode)+
  labs(x='Master Regulators', y='-logSig Enrichment')+
  theme_bw(base_size = 30)
dev.off()

# Venn Diagram
OT_score = NC_offTarg_meanscore;size_p53=length(p53.CDEpos); size_kras=length(kras.CDEpos)
size_vhl=length(vhl.CDEpos)
GenelistOT_score_ordered = rownames(OT_score)[order(OT_score$score, decreasing = T)]

c(overlap = length(intersect(head(GenelistOT_score_ordered, size_p53), p53.CDEpos)),
  test_list = length(size_p53),
  base_list = length(p53.CDEpos))
c(overlap = length(intersect(head(GenelistOT_score_ordered, size_kras), kras.CDEpos)),
  test_list = length(size_kras),
  base_list = length(kras.CDEpos))
c(overlap = length(intersect(head(GenelistOT_score_ordered, size_vhl), vhl.CDEpos)),
  test_list = length(size_vhl),
  base_list = length(vhl.CDEpos))

