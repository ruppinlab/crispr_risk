# KRAS DE ranking
score=KRAS_effect[,2]
names(score)=rownames(KRAS_effect)
KRAS_crisprRanking_pathways_enrichment=enriched_pathway(score = score,
                                        pathways_list = hallmark_genes)
tiff('/Users/sinhas8/Project_CRISPR/KRAS_crispr_ranking_HallmarkpathwayGSEA.tiff',
     width = 800, height = 800)
ggplot(KRAS_crisprRanking_pathways_enrichment, aes(x=NES, y=-log(padj), label=pathway))+
  geom_point()+
  geom_label_repel()+
  geom_hline(yintercept =  - log(0.1), color='red', linetype='longdash')+
  geom_vline(xintercept =  0, color='black', size=2)+
  theme_bw(base_size = 20)+
  theme(legend.position = 'none')+
  labs( y= '-log(FDR)', x='effect size(NES)')
dev.off()

KRAS_crisprRanking_pathways_enrichment=enriched_pathway(score = score,
                                                        pathways_list = DDR_Geneset_List)

tiff('/Users/sinhas8/Project_CRISPR/KRAS_crispr_ranking_DDRpathwayGSEA.tiff',
     width = 800, height = 800)
ggplot(KRAS_crisprRanking_pathways_enrichment, aes(x=NES, y=-log(padj), label=pathway))+
  geom_point()+
  geom_label_repel()+
  geom_hline(yintercept =  - log(0.1), color='red', linetype='longdash')+
  geom_vline(xintercept =  0, color='black', size=2)+
  theme_bw(base_size = 20)+
  theme(legend.position = 'none')+
  labs( y= '-log(FDR)', x='effect size(NES)')
dev.off()
