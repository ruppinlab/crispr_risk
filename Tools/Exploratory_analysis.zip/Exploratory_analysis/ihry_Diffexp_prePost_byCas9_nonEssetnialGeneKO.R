# pathview
ihry=readxl::read_xlsx('/Users/sinhas8/Downloads/41591_2018_50_MOESM7_ESM (2).xlsx')
install.packages('pathview')
head(gse16873.d)
lfc=ihry$
names(lfc)=ihry$Entrez
pv.out <- pathview(gene.data = lfc, pathway.id = "04014",
                   species = "hsa", out.suffix = "gse16873",)
data("gene.idtype.list")
pathview()
