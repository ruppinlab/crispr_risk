# Test for correlation btw KRAS and P53 subclones
kras_mut=comp_natGen[comp_natGen$Canonical_Variant_Classification!='intron',]
comp_natGen=comp_natGen[comp_natGen$Canonical_Variant_Classification!='intron',]
dim(aggregate(Hugo_Symbol ~ Cell_Line_Origin, data = comp_natGen, function(x) table(x)))
p53_mut=comp_natGen[comp_natGen$Hugo_Symbol=='TP53' & comp_natGen$Canonical_Variant_Classification!='intron',]