#####Write sgRNA sequences in FASTA
require(parallel)
require(seqinr)
setwd("/Users/sinhas8/Project_CRISPR/2.Data/")
sgRNA=read.csv('sgRNA_with_GeneMapping.csv')
dim(sgRNA)
sgRNA_list=mclapply(sgRNA$sgrna,  function(x) paste(as.character(x), 'NGG', sep=''), mc.cores = detectCores())

K=length(sgRNA_list)
write.fasta(sequences = sgRNA_list[1:K], names = make.names(sgRNA$gene, unique = T)[1:K],
            file.out = "/Users/sinhas8/Project_CRISPR/2.Data/offtarget_data/sgRNA_sequences_avana_foroffTarget_scores.fa")

# ##for sftp
# cd /data/sinhas8/Proj_CRISPR_OffTarget
# put /Users/sinhas8/Project_CRISPR/2.Data/offtarget_data/sgRNA_sequences_avana_foroffTarget_scores.fa
# 

# sftp sinhas8@biowulf.nih.gov
# lcd '/Users/sinhas8/Project_CRISPR/3.Tools/'
# cd /home/sinhas8/
# put sgRNA_offtarget.R
# put /Users/sinhas8/Gandalf.sh
