# Identify SL screens
source('/Users/sinhas8/myCustom_functions.R')
onTarget=readRDS('/Users/sinhas8/Project_OffTarget/2.Data/onTarget_v2.RDS')
drug_kras=readxl::read_xlsx('/Users/sinhas8/Downloads/41467_2020_16078_MOESM12_ESM.xlsx')
head(drug_kras$`Average AUC Ratio`, 10)

# mapping=sapply(tolower(onTarget$drugCategory$name), 
#                function(x) err_handle(grep(x, tolower(drug_kras$Drug))) )
# unique(na.omit(unlist(mapping[which(sapply(mapping, length)>0)])))
drug_kras$`Percent Change`[which(onTarget$drugCategory$drug_category[match(tolower(drug_kras$Drug), tolower(onTarget$drugCategory$name))]=='chemo')]
hist(drug_kras$`Percent Change`, 20)


