require(VennDiagram)
B1=draw.pairwise.venn(area1= length(CDE$p53.CDE.),
                      area2= length(p53_CDE_pos),
                      cross.area=length(intersect(CDE$p53.CDE.[1:861], 
                                                  p53_CDE_pos)) ,
                      category= c("Prev CDE+", "New CDE+"),
                      fill= c('#e41a1c','#377eb8'),
                      main='Recurrent',
                      cex= 3,
                      scaled=FALSE,
                      alpha=0.8,
                      cat.cex = 2,
                      cat.pos = 0)
B2=draw.pairwise.venn(area1= 185,
                      area2= length(p53_CDE_neg),
                      cross.area=length(intersect(CDE$p53.CDE..1[1:185], 
                                                  p53_CDE_neg)) ,
                      category= c("Prev CDE-", "New CDE-"),
                      fill= c('#e41a1c','#377eb8'),
                      main='Recurrent',
                      cex= 3,
                      scaled=FALSE,
                      alpha=0.8,
                      cat.cex = 2,
                      cat.pos=0)
combine_plot = plot_grid(grid.arrange(gTree(children=B1)),
                           grid.arrange(gTree(children=B2)),
                           nrow=2)
tiff('/Users/sinhas8/Downloads/Overlap.tiff', width = 400, height = 800)
plot(combine_plot)
dev.off()


# Venn Diagram for Overlap with off Target genes
overlap_for_p53=c(overlap = length(intersect(head(GenelistOT_score_ordered, size_p53), p53.CDEpos)),
  test_list = size_p53,
  base_list = length(p53.CDEpos))
overlap_for_kras=c(overlap = length(intersect(head(GenelistOT_score_ordered, size_kras), kras.CDEpos)),
  test_list = size_kras,
  base_list = length(kras.CDEpos))
overlap_for_vhl=c(overlap = length(intersect(head(GenelistOT_score_ordered, size_vhl), vhl.CDEpos)),
  test_list = size_vhl,
  base_list = length(vhl.CDEpos))

B1=draw.pairwise.venn(area1= overlap_for_vhl[2],
                      area2= overlap_for_vhl[3],
                      cross.area=overlap_for_vhl[1],
                      category= c("vhl CDE+", "OffTarget\n Prone Genes"),
                      fill= c('#e41a1c','#377eb8'),
                      main='Recurrent',
                      cex= 3,
                      scaled=TRUE,
                      alpha=0.8,
                      cat.cex = 2,
                      cat.pos = 0)
combine_plot = plot_grid(grid.arrange(gTree(children=B1)),nrow=1)

tiff('/Users/sinhas8/Downloads/vhlCDE_explainedbyOT.tiff',
     width = 400, height = 400)
plot(combine_plot)
dev.off()

