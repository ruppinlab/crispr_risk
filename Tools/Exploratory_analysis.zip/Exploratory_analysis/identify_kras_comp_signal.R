########################################################
# Add score
########################################################
source('/Users/sinhas8/myCustom_functions.R')
library(data.table)
dat <- fread("/Users/sinhas8/Downloads/kras.tsv")
dat <- dat[, .(gene=Gene, rep=Rep, y=`TdTomato%`, t=Timepoint, sgRNA=Sequence)]
tmp <- dat[, .(n=uniqueN(sgRNA)), by=gene][n==1, gene]
tmp1 <- dat[gene %in% tmp, as.list(coef(summary(lm(y ~ t)))["t",c("Estimate","Std. Error","Pr(>|t|)")]),
            by=gene]
tmp2 <- dat[!gene %in% tmp, as.list(coef(summary(lm(y ~ t + sgRNA)))["t",c("Estimate","Std. Error","Pr(>|t|)")]), by=gene]
res <- rbind(tmp1, tmp2)
setnames(res, c("gene","coef","se","pval"))
res <- res[order(-coef)]
########################################################
# Add expression values
########################################################
onTarget=readRDS('/Users/sinhas8/Project_OffTarget/2.Data/onTarget_v2.RDS')
########################################################
# Add expression values
########################################################
offTarget=readRDS('/Users/sinhas8/Project_CRISPR/2.Data/Off_Target_Scores.RDS')
offTarget_Score=offTarget$summary[,c(1, 6, 7)]
offTarget_Score=cbind(offTarget_Score, 
                      seq=substring(offTarget$summary$gRNAsPlusPAM, 0,20))
dat$off_score=offTarget_Score$top100OfftargetTotalScore[match(dat$sgRNA, offTarget_Score$seq)]
###################
# Try1 : Inconsistent sgRNA
###################
inconsistentsgRNA=which(!(offTarget_Score$GeneNames[
  match(dat$sgRNA,offTarget_Score$seq)]== dat$gene))
test_with_a_subsetofsgRNAs<-function(id2remove, whether_remove=T){
  dat <- fread("/Users/sinhas8/Downloads/kras.tsv")
  dat <- dat[, .(gene=Gene, rep=Rep, y=`TdTomato%`, t=Timepoint, sgRNA=Sequence)]
  if(whether_remove){dat=dat[-id2remove,]}
  tmp <- dat[, .(n=uniqueN(sgRNA)), by=gene][n==1, gene]
  tmp1 <- dat[gene %in% tmp, as.list(coef(summary(lm(y ~ t)))["t",c("Estimate","Std. Error","Pr(>|t|)")]),
              by=gene]
  tmp2 <- dat[!gene %in% tmp, as.list(coef(summary(lm(y ~ t + sgRNA)))["t",c("Estimate","Std. Error","Pr(>|t|)")]), by=gene]
  res <- rbind(tmp1, tmp2)
  setnames(res, c("gene","coef","se","pval"))
  res <- res[order(-coef)]
  c(sum(res$coef>0), sum(res$coef<0))
}
test_with_a_subsetofsgRNAs(inconsistentsgRNA, whether_remove = F)
test_with_a_subsetofsgRNAs(inconsistentsgRNA, whether_remove = T)

###################
# Try2 : use Pooled rank screens
###################
res_withPoolScore=cbind(res, poolScore)
require(ggplot2)
ggplot(res_withPoolScore, aes(x=coef, y=FC_diff_crisprcas9))+
  geom_point()+
  geom_smooth(method = 'lm', formula =  y~x)
cor.test(res_withPoolScore$coef, res_withPoolScore$FC_diff_crisprI, 
         method = 'spe')

###################
# Try3 : use Pooled rank screens
###################
require(statar)
save_dat=dat
moreOffTargetsgRNA<-function(dat=save_dat, K=2, whether_remove=F){
  if(whether_remove){dat=dat[which(xtile(dat$off_score, K)==K), ]}
  tmp <- dat[, .(n=uniqueN(sgRNA)), by=gene][n==1, gene]
  tmp1 <- dat[gene %in% tmp, as.list(coef(summary(lm(y ~ t)))["t",c("Estimate","Std. Error","Pr(>|t|)")]),
              by=sgRNA]
  tmp2 <- dat[!gene %in% tmp, as.list(coef(summary(lm(y ~ t)))["t",c("Estimate","Std. Error","Pr(>|t|)")]),
              by=sgRNA]
  res <- rbind(tmp1, tmp2)
  setnames(res, c("gene","coef","se","pval"))
  res <- res[order(-coef)]
  c(sum(res$coef>0), sum(res$coef<0))
  res
}
median(moreOffTargetsgRNA(dat=save_dat, K=2, whether_remove=T)$coef)
###################
# Try4 : Expression
###################
molm_id=onTarget$annotation$depMapID[grep('MOLM-13',onTarget$annotation$Name)]
onTarget$expression[molm_id]
unique(names(which(onTarget$expression[match(dat$gene, rownames(onTarget$expression)),
                           molm_id]==0)))
###################
# Try4 : Expression
###################

