# Check for Chemo and GDSC
################################################################
##Load dataset
################################################################
require(ggplot2)
require(ggpubr)
require(quantreg)
setwd('/Users/sinhas8/Downloads/')
gdsc=read.csv('GDSC_AUC.csv')
metadata=read.csv('Cell_lines_annotations_20181226 (2).txt', sep='\t')
err_handle<-function(x){ tryCatch(x, error=function(e){NA}) }
mapping=read.csv('Screened_Compounds.csv')

################################################################
##FOR GDSC
################################################################
################################################################
##Pre-preprocessing
################################################################
metadata$depMapID=gsub('-','.',metadata$depMapID)
metadata=metadata[na.omit(match(colnames(gdsc), metadata$depMapID)),]
GDSC_Drugs_Id=gdsc$X
gdsc=gdsc[,!is.na(match(colnames(gdsc), metadata$depMapID))]
levels(metadata$inferred_ethnicity)=c('AA','AS','EA')
mapping=mapping[match(gsub('GDSC:','',GDSC_Drugs_Id), mapping$DRUG_ID),]
onTarget$gdsc=gdsc
colnames(onTarget$gdsc)=gsub('\\.','-', colnames(onTarget$gdsc))
################################################################
##Find common
################################################################
COI=intersect(colnames(onTarget$gdsc), colnames(onTarget$mutations_matrix))
GOI=c('TP53', 'KRAS')
K=1
gdsc_drug_p53=t(apply(onTarget$gdsc[,COI], 1, function(x) 
  c(p=wilcox.test(x ~ factor(unlist(onTarget$mutations_matrix[GOI[K],COI])))$p.value,
    FC=median(x[factor(unlist(onTarget$mutations_matrix[GOI[K],COI]))==0], na.rm = T)/
      median(x[factor(unlist(onTarget$mutations_matrix[GOI[K],COI]))==1], na.rm = T))))
rownames(gdsc_drug_p53)=onTarget$gdsc_mapping$DRUG_NAME

chemodrugs=which(onTarget$drugCategory$drug_category[match(tolower(rownames(gdsc_drug_p53)), tolower(onTarget$drugCategory$name))]=='chemo')

sum(gdsc_drug_p53[,1]<0.1 & gdsc_drug_p53[,2]>1)
sum(gdsc_drug_p53[,1]<0.1 & gdsc_drug_p53[,2]<1)
# For chemo drugs
sum(gdsc_drug_p53[chemodrugs,1]<1 & gdsc_drug_p53[chemodrugs,2]>1)
sum(gdsc_drug_p53[chemodrugs,1]<1 & gdsc_drug_p53[chemodrugs,2]<1)

resp=c(apply(onTarget$gdsc[chemodrugs, COI], 1, scale))

p53=unlist(onTarget$mutations_matrix[GOI, COI])
df2plot=data.frame(resp, t(p53))
wilcox.test(df2plot$resp ~ df2plot$TP53, alternative='l')
