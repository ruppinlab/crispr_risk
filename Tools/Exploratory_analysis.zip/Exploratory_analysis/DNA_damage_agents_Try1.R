onTarget=readRDS('/Users/sinhas8/Project_OffTarget/2.Data/onTarget_v2.RDS')
chemo_drugs=which(onTarget$drugCategory$drug_category=='chemo')
common=intersect(colnames(onTarget$drug_prism),colnames(onTarget$mutations_matrix)) 

onTarget$drugCategory$name[chemo_drugs[which(diff_exp_byGenes$TP53[chemo_drugs,1]>0 &
                                               diff_exp_byGenes$TP53[chemo_drugs,2]<0.1)]]
onTarget$drugCategory$name[chemo_drugs[which(diff_exp_byGenes$TP53[chemo_drugs,1]<0 &
                                               diff_exp_byGenes$TP53[chemo_drugs,2]<0.1)]]

onTarget$drugCategory$name[chemo_drugs[which(diff_exp_byGenes$KRAS[chemo_drugs,1]>0 &
                                               diff_exp_byGenes$KRAS[chemo_drugs,2]<0.1)]]
onTarget$drugCategory$name[chemo_drugs[which(diff_exp_byGenes$KRAS[chemo_drugs,1]<0 &
                                               diff_exp_byGenes$KRAS[chemo_drugs,2]<0.1)]]