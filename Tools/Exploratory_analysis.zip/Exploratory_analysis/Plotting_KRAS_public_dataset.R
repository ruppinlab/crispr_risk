setwd('/Users/sinhas8/Project_CRISPR/Project_CRISPR.Risk_Github/')
source('Tools/Step0_Globally_used_Functions_and_Datasets.R')

# Centralized pipeline for All screenings
########################################################################
# Load CDE positive genes identified from avana screens
########################################################################
CDE=read.csv('Data/CDEs_of_ThreeMaster_Regulators.csv')
CDE=lapply(CDE, function(x) as.character(x[x!='']) )

# ***Publicly available Data***
K=6
################################################################
##KRAS DLD1 - shRNA shRNA
################################################################
#shRNA screenings in DLD1 isogenic KRAS mutated and WT pair. 
# from https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2768667/
# Ji Luo et al.
df_DLD1_shRNA=read.csv('Data/Isogenic_Screenings/KRAS_isogenic_shRNA_screening.csv')
df_DLD1_shRNA=df_DLD1_shRNA[!is.na(match(df_DLD1_shRNA$Gene_Symbol, rownames(avana))),]
df_DLD1_shRNA$GeneType=NA
df_DLD1_shRNA$GeneType[!is.na(match(df_DLD1_shRNA$Gene_Symbol, head(CDE$KRAS.CDE.Pos, K)))]='KRAS CDE Pos'
df_DLD1_shRNA$GeneType[!is.na(match(df_DLD1_shRNA$Gene_Symbol, CDE$KRAS.CDE.Neg))]='KRAS CDE Neg'
df_DLD1_shRNA$GeneType[!(!is.na(match(df_DLD1_shRNA$Gene_Symbol, head(CDE$KRAS.CDE.Pos, K))) |
                           !is.na(match(df_DLD1_shRNA$Gene_Symbol, CDE$KRAS.CDE.Neg))) ]='KRAS CDE Neutral'
################################################################
##KRAS CRSIPR- DLD1
################################################################
# CRISPR-Cas9 screenings in DLD1 isogenic KRAS mutated and WT pair. 
# from https://www.cell.com/cell-reports/pdfExtended/S2211-1247(17)30892-6
# Martine et al 2017
# Load Martin et al Screens for DLD1 cell lines 
df_DLD1_crispr=read.csv('Data/Isogenic_Screenings/KRAS_genomeWide_CRISPRcas9_screen_DLD1_Martin_.csv')
df_DLD1_crispr=df_DLD1_crispr[!is.na(match(df_DLD1_crispr$Gene, rownames(avana))),]
df_DLD1_crispr$GeneType=NA
df_DLD1_crispr$GeneType[!is.na(match(df_DLD1_crispr$Gene, head(CDE$KRAS.CDE.Pos, K)))]='KRAS CDE Pos'
df_DLD1_crispr$GeneType[!is.na(match(df_DLD1_crispr$Gene, CDE$KRAS.CDE.Neg))]='KRAS CDE Neg'
df_DLD1_crispr$GeneType[!(!is.na(match(df_DLD1_crispr$Gene, head(CDE$KRAS.CDE.Pos, K))) |
                            !is.na(match(df_DLD1_crispr$Gene, CDE$KRAS.CDE.Neg))) ]='KRAS CDE Neutral'
################################################################
##KRAS CRSIPR - HCT116
################################################################
df_HCT116_crispr=read.csv('Data/Isogenic_Screenings/KRAS_Martin_HCT116.csv')
df_HCT116_crispr=df_HCT116_crispr[!is.na(match(df_HCT116_crispr$Gene, rownames(avana))),]
df_HCT116_crispr$GeneType=NA
df_HCT116_crispr$GeneType[!is.na(match(df_HCT116_crispr$Gene, head(CDE$KRAS.CDE.Pos, K)))]='KRAS CDE Pos'
df_HCT116_crispr$GeneType[!is.na(match(df_HCT116_crispr$Gene, CDE$KRAS.CDE.Neg))]='KRAS CDE Neg'
df_HCT116_crispr$GeneType[!(!is.na(match(df_HCT116_crispr$Gene, head(CDE$KRAS.CDE.Pos, K))) |
                              !is.na(match(df_HCT116_crispr$Gene, CDE$KRAS.CDE.Neg))) ]='KRAS CDE Neutral'

################################################################
##Test Method
################################################################

##Test-Try1:: Method 1
# *Results* : Testing CDE+/- essentiality direction in CRISPR DLD1 screening
# Using direct FC score
# FC_shRNAvsCRISPR<-function(
  cde_type="KRAS CDE Pos"
                           # ){
  df_HCT116_crispr_kras=df_HCT116_crispr
  df_DLD1_crispr_kras=df_DLD1_crispr
  
  ##Test after Scaling
  # df_DLD1_shRNA$KRAS.Mut.log2.mean=scale(df_DLD1_shRNA$KRAS.Mut.log2.mean)
  # df_DLD1_shRNA$KRAS.WT.log2.Mean=scale(df_DLD1_shRNA$KRAS.WT.log2.Mean)
  # df_DLD1_crispr_kras$WT.log2.fold.change=scale(df_DLD1_crispr_kras$WT.log2.fold.change)
  # df_DLD1_crispr_kras$KRas.mutant.log2.fold.change=scale(df_DLD1_crispr_kras$KRas.mutant.log2.fold.change)
  # df_HCT116_crispr_kras$WT.log2.fold.change=scale(df_HCT116_crispr_kras$WT.log2.fold.change)
  # df_HCT116_crispr_kras$KRas.mutant.log2.fold.change=scale(df_HCT116_crispr_kras$KRas.mutant.log2.fold.change)
  
  FC_inMutant_shRNA=df_DLD1_shRNA$KRAS.Mut.log2.mean[which(df_DLD1_shRNA$GeneType==cde_type)]
  FC_inWT_shRNA=df_DLD1_shRNA$KRAS.WT.log2.Mean[which(df_DLD1_shRNA$GeneType==cde_type)]
  FC_inMutant_crispr=df_DLD1_crispr_kras$WT.log2.fold.change[which(df_DLD1_crispr_kras$GeneType==cde_type)]
  FC_inWT_crispr=df_DLD1_crispr_kras$KRas.mutant.log2.fold.change[which(df_DLD1_crispr_kras$GeneType==cde_type)]
  FC_inMutant_crispr2=df_HCT116_crispr_kras$WT.log2.fold.change[df_HCT116_crispr_kras$GeneType==cde_type]
  FC_inWT_crispr2=df_HCT116_crispr_kras$KRas.mutant.log2.fold.change[df_HCT116_crispr_kras$GeneType==cde_type]
  # FC_inMutant=df_HCT116_crispr_kras$Rank_Mut[df_HCT116_crispr_kras$GeneType==cde_type]
  # FC_inWT=df_HCT116_crispr_kras$Rank_WT[df_HCT116_crispr_kras$GeneType==cde_type]
  
  df2plot=rbind(
    data.frame(FC_change=FC_inMutant_shRNA, KRAS_Status='KRAS-Mut', Method='shRNA', Type='CDE+'),
    data.frame(FC_change=FC_inWT_shRNA, KRAS_Status='KRAS-WT', Method='shRNA', Type='CDE+')
    ,data.frame(FC_change=FC_inMutant_crispr, KRAS_Status='KRAS-Mut', Method='CRISPR-Cas9', Type='CDE+'),
    data.frame(FC_change=FC_inWT_crispr, KRAS_Status='KRAS-WT', Method='CRISPR-Cas9', Type='CDE+')
    # ,data.frame(FC_change=FC_inMutant_crispr2, MR='KRAS-Mut', Method='CRISPR-Cas9', Type='CDE+'),
    # data.frame(FC_change=FC_inWT_crispr2, MR='KRAS-WT', Method='CRISPR-Cas9', Type='CDE+')
  )
  
  df2plot$KRAS_Status=factor(df2plot$KRAS_Status, levels = rev(levels(df2plot$KRAS_Status)))
  pdf('Plots/Publicly_available_dataSet.pdf')  
  ggplot(df2plot, aes(y=FC_change, fill=KRAS_Status, x=Method))+
    geom_boxplot(outlier.shape = NA)+
    facet_wrap(.~Type)+
    stat_compare_means(label = 'p', method.args = list(alternative='l'),
                       paired=T, method='wilcox', size=7)+
    theme_classic(base_size = 25)+
    theme(legend.position = 'top', legend.title = element_blank(), legend.key.size = unit(3, "lines"))+
      labs(x='Method', y='Cell Viability after KO')+
    scale_fill_manual(values = c('grey', 'indianred2'))
  dev.off()  
# }
