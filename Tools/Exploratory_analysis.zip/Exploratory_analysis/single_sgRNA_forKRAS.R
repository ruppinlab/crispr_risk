# NTC
karina_assay=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/Isogenic_Screenings/p53_CDEScreening_Mutant.csv')
sort(table(as.character(karina_assay$Gene[grep('NTC',karina_assay$Gene)])), decreasing = T)
na.omit(match(levels(karina_assay$Gene), )))
molm_id=onTarget$annotation$depMapID[grep('MOLM13',onTarget$annotation$CCLE_ID)]
not_expressed_molm=names(which(onTarget$expression[,as.character(molm_id)]==0))
table(as.character(karina_assay$Gene[!is.na(match(karina_assay$Gene, not_expressed_molm))]))
