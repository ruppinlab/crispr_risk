# Subset of drugs targeting DE+ genes of P53 and KRAS
drugs_inp53DE=sapply(onTarget$Annotated_Target, function(x) sum(strsplit(as.character(x), split = ', ')[[1]]
       %in% as.character(de_genes$DE_pos_TP53$rownames.avana..Sig_TP53..1.....1..)) )
id_drugs_inp53DE=which(drugs_inp53DE>0)
drugs_inKRASDE=sapply(onTarget$Annotated_Target, function(x) sum(strsplit(as.character(x), split = ', ')[[1]]
                                                                %in% as.character(de_genes$DE_pos_KRAS$rownames.avana..Sig..1.....1..)) )
id_drugs_inKRASDE=which(drugs_inKRASDE>0)

# Identify the drugNames_withinDE
# for TP53
p53_DiffResp_drugNames_fromp53DE_id=which(diff_exp_byGenes$TP53[id_drugs_inp53DE,1]>0.1
                                          & fdrcorr(diff_exp_byGenes$TP53[id_drugs_inp53DE,2])<0.1)
p53_DiffResp_drugNames_fromp53DE_Name=onTarget$drugsCommonName[id_drugs_inp53DE][p53_DiffResp_drugNames_fromp53DE_id]
# for KRAS
KRAS_DiffResp_drugNames_fromKRASDE_id=which(diff_exp_byGenes$KRAS[id_drugs_inKRASDE,1]>0.1
                                          & fdrcorr(diff_exp_byGenes$KRAS[id_drugs_inKRASDE,2])<0.1)
KRAS_DiffResp_drugNames_fromKRASDE_Name=onTarget$drugsCommonName[id_drugs_inKRASDE][KRAS_DiffResp_drugNames_fromKRASDE_id]
