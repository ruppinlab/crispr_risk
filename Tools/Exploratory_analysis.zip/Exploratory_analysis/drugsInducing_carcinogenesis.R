######################################################
# Checking drugs-inducing carcinogenesis idea: Step 0
######################################################
require(parallel)
geneSum=apply(onTarget$mutations_matrix, 1, sum)
cancer_genes=read.csv('/Users/sinhas8/Project_OffTarget/COSMIC.csv', sep='\t')
freqMut_cancerGenes=names(which(geneSum[as.character(cancer_genes$Gene.Symbol)]>160))
freqMut_cancerGenes=c('TP53')
common_colnames=intersect(colnames(onTarget$drug_prism),
                          colnames(onTarget$mutations_matrix))
# Devise a test
cancer_type=onTarget$annotation$tcga_code[match(common_colnames, 
                                                onTarget$annotation$depMapID)]
diff_exp<-function(geneName=freqMut_cancerGenes[1],
                   drugResponse=onTarget$drug_prism){
  mat2return=do.call(rbind, mclapply(1:nrow(drugResponse), function(x) 
    summary(lm(drugResponse[x,common_colnames] ~ 
                 onTarget$mutations_matrix[geneName,common_colnames]))$coefficient[2,c(1,4)]))
  mat2return
}
diff_exp_byGenes=lapply(freqMut_cancerGenes, function(x) diff_exp(geneName=x))
names(diff_exp_byGenes)=freqMut_cancerGenes
drugNames=sapply(diff_exp_byGenes, function(x)
  onTarget$drugsCommonName[which(x[,1]>0.1 & fdrcorr(x[,2])<0.1)])
drugNames_scores=lapply(diff_exp_byGenes, function(x)
  diff_exp_byGenes$TP53[which(x[,1]>0.1 & fdrcorr(x[,2])<0.1),])[[1]]
drugNames_withScores=data.frame(drugNames, drugNames_scores)
drugNames_withScores=drugNames_withScores[order(drugNames_withScores$Estimate, decreasing = T),]
drugNames_withScores$target=onTarget$drugCategory$target[match(drugNames_withScores$TP53, onTarget$drugsCommonName)]
drugNames_withScores[grep('MDM2',drugNames_withScores$target),]
# drugNames=drugNames[sapply(drugNames, length)>0]
######################################################
# Target Enrichment
######################################################
score=diff_exp_byGenes$TP53[,1]
names(score)=onTarget$drugsCommonName
head(data.frame(score, onTarget$drugCategory$target))
score_extended=rep(score,
                   sapply(unlist(onTarget$drugCategory$target),
                          function(x) length(strsplit(as.character(x), ', ')[[1]])))
names(score_extended)=unlist(sapply(unlist(onTarget$drugCategory$target),
                                    function(x) strsplit(as.character(x), ', ')[[1]]))
require(fgsea)
enriched_pathway<-function(geneList=names(diffscore),
                           score=diffscore,
                           pathways_list=DDR_Geneset_List){
  # genelist: genelist of interest (vector. eg. All genes)
  # score: output score to rank the genelist (vector, eg. Expression fold change)
  # pathways_list: List of pathways to test your enrichment for (list of vectors, eg. GO pathways)
  names(score)<-geneList
  score=na.omit(score)
  score=score[!is.infinite(score)]
  gsea.res <- fgsea(pathways_list, score, 1e4, minSize = 0)
  gsea.res=gsea.res[order(gsea.res$pval),]
  gsea.res=as.data.frame(gsea.res[,1:5])
  gsea.res
}
# pathway_enr=enriched_pathway(score = score_extended,
#                              geneList = names(score_extended),
#                              pathways_list=GO_pathways)

gsea.res.hyp.carc=pathway_enr
gsea.res.hyp.carc$Enriched_in='negative Enrichment'
gsea.res.hyp.carc$Enriched_in[gsea.res.hyp.carc$ES>0]='positive Enrichment'
gsea.res.hyp.carc=gsea.res.hyp.carc[order(gsea.res.hyp.carc$pval),]
gsea.res.hyp.carc$Enriched_in=factor(gsea.res.hyp.carc$Enriched_in, labels=c('Pos Enriched',
                                                                             'Neg Enriched'))
tiff('pathway_enriched.tiff', width = 600, height = 400)
ggplot(gsea.res.hyp.carc[1:10,], aes(x=reorder(pathway, -pval, FUN = median),
                                     y= -log(pval, 10), fill=Enriched_in))+
  geom_bar(stat = 'identity')+
  coord_flip()+
  theme_bw(base_size = 16)+
  theme(axis.text.y = element_text(angle = 0), legend.position = 'top', legend.title = element_blank(),
        legend.justification='left', legend.direction='vertical')+
  labs(x='', y='-log10(P)')+
  ggtitle('Enrichment by MOA')+
  geom_hline(yintercept = 1.3, linetype='dashed', size=1.5, color='blue')
dev.off()
# DDR pathways
pathway_enr=enriched_pathway(score = score_extended, geneList = names(score_extended),
                             pathways_list = DDR_Geneset_List)

gsea.res.hyp.carc=pathway_enr
gsea.res.hyp.carc$Enriched_in='negative Enrichment'
gsea.res.hyp.carc$Enriched_in[gsea.res.hyp.carc$ES>0]='positive Enrichment'
gsea.res.hyp.carc=gsea.res.hyp.carc[order(gsea.res.hyp.carc$pval),]
gsea.res.hyp.carc$Enriched_in=factor(gsea.res.hyp.carc$Enriched_in, labels=c('Pos Enriched',
                                                                             'Neg Enriched'))
tiff('/Users/sinhas8/Project_Drugs_selelecting_Driver_mutations/DDR_pathway_enriched.tiff',
     width = 600, height = 400)
ggplot(gsea.res.hyp.carc, aes(x=reorder(pathway, -pval, FUN = median),
                              y= -log(pval, 10), fill=Enriched_in))+
  geom_bar(stat = 'identity')+
  coord_flip()+
  theme_bw(base_size = 16)+
  theme(axis.text.y = element_text(angle = 0), legend.position = 'top', legend.title = element_blank(),
        legend.justification='left', legend.direction='vertical')+
  labs(x='', y='-log10(P)')+
  ggtitle('Enrichment by MOA')+
  geom_hline(yintercept = 1.3, linetype='dashed', size=1.5, color='blue')
dev.off()
# DE gene enrichment
head()
pathway_enr=enriched_pathway(score = score_extended, geneList = names(score_extended),
                             pathways_list = list(Hits_from_genetic_screens=de_genes$DE_pos_TP53$rownames.avana..Sig_TP53..1.....1..))

gsea.res.hyp.carc=pathway_enr
gsea.res.hyp.carc$Enriched_in='negative Enrichment'
gsea.res.hyp.carc$Enriched_in[gsea.res.hyp.carc$ES>0]='positive Enrichment'
gsea.res.hyp.carc=gsea.res.hyp.carc[order(gsea.res.hyp.carc$pval),]
gsea.res.hyp.carc$Enriched_in=factor(gsea.res.hyp.carc$Enriched_in, labels=c('Pos Enriched'))
tiff('/Users/sinhas8/Project_Drugs_selelecting_Driver_mutations/GeneticScreen_Hits_pathway_enriched.tiff',
     width = 600, height = 100)
ggplot(gsea.res.hyp.carc, aes(x=reorder(pathway, -pval, FUN = median),
                              y= -log(pval, 10), fill=Enriched_in))+
  geom_bar(stat = 'identity')+
  coord_flip()+
  theme_bw(base_size = 16)+
  theme(axis.text.y = element_text(angle = 0), legend.position = 'none',
        legend.title = element_blank(),
        legend.justification='left', legend.direction='vertical')+
  labs(x='', y='-log10(P)')+
  geom_hline(yintercept = 1.3, linetype='dashed', size=1.5, color='blue')
dev.off()
######################################################
# Enrichment in DE/CDE genes
######################################################
tp53_genes=na.omit(unlist(sapply(onTarget$drugCategory$target[match(unlist(drugNames[,1]), 
                                   onTarget$drugCategory$name)], function(x)
                                     gsub(' ','',strsplit(as.character(x), ',')[[1]]) )))
de_genes=readRDS('/Users/sinhas8/Project_CRISPR/2.Data/DE_genes.RDS')
hypergeometric_test_for_twolists(test_list = tp53_genes,
                                 base_list = de_genes$DE_pos_TP53$rownames.avana..Sig_TP53..1.....1..,
                                 global = rownames(onTarget$avana))

cde_genes=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/CDE_allThree.csv')
hypergeometric_test_for_twolists(test_list = tp53_genes,
                                 base_list = de_genes$DE_pos_TP53$rownames.avana..Sig_TP53..1.....1..[!de_genes$DE_pos_TP53$rownames.avana..Sig_TP53..1.....1.. %in% cde_genes$p53.CDE.],
                                 global = rownames(onTarget$avana))

DDR=read.csv('/Users/sinhas8/Downloads/DDR_Genes.csv')
colnames(DDR$Gene.Symbol); colnames(DDR)
DDR_Geneset_List=apply(DDR[,c(11:29)], 2, function(x) unlist(x[x!='']) )
sapply(DDR_Geneset_List, function(x) grep('IDH',x))
unlist(DDR_Geneset_List)
sapply(names(DDR_Geneset_List), function(x) hypergeometric_test_for_twolists(test_list = unique(tp53_genes),
                                                                             base_list = unlist(DDR_Geneset_List[x]),
                                                                             global = rownames(onTarget$avana)))
# KRAS genes
kras_genes=na.omit(unlist(sapply(onTarget$drugCategory$target[match(unlist(drugNames$KRAS), 
                                                                    onTarget$drugCategory$name)], function(x)
                                                                      gsub(' ','',strsplit(as.character(x), ',')[[1]]) )))
de_genes=readRDS('/Users/sinhas8/Project_CRISPR/2.Data/DE_genes.RDS')
hypergeometric_test_for_twolists(test_list = kras_genes,
                                 base_list = de_genes$DE_pos_KRAS$rownames.avana..Sig..1.....1..,
                                 global = rownames(onTarget$avana))

cde_genes=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/CDE_allThree.csv')
hypergeometric_test_for_twolists(test_list = kras_genes,
                                 base_list = de_genes$DE_pos_KRAS$rownames.avana..Sig..1.....1..[!de_genes$DE_pos_KRAS$rownames.avana..Sig..1.....1.. %in% cde_genes$KRAS.CDE.],
                                 global = rownames(onTarget$avana))
sapply(names(DDR_Geneset_List), function(x) hypergeometric_test_for_twolists(test_list = kras_genes,
                                                                             base_list = unlist(DDR_Geneset_List[x]),
                                                                             global = rownames(onTarget$avana)))
# other genes
unlist(sapply(onTarget$drugCategory$target[match(unlist(drugNames[c(4)]), 
                                                 onTarget$drugCategory$name)], function(x)
                                                   gsub(' ','',strsplit(as.character(x), ',')[[1]]) ))
######################################################
# FDA approved
######################################################
# FDA approved drugs
fda_approved_table=read.csv('/Users/sinhas8/Project_COVID19/Data/fda_approved_maybe_allDrugs.csv')
head(fda_approved_table)
fda_approved_only=fda_approved_table[grep('FDA',fda_approved_table$Status),]
fda_approved_only_ofInterest=fda_approved_only[na.omit(match(tolower(unlist(drugNames$TP53)),
                                    tolower(fda_approved_only$name))),]

dim(fda_approved_only_ofInterest)
fda_approved_only_ofInterest=fda_approved_only_ofInterest[-grep('cancer',
                                  fda_approved_only_ofInterest$Indication,
                                  ignore.case = T),]

fda_approved_only_ofInterest=fda_approved_only_ofInterest[,c('name', 'Status', 'Indication', 'Target', 'Pathway', 'Information')]
head(fda_approved_only_ofInterest)
drugs2targets[grep('doxycycline',drugs2targets$drug.name, ignore.case = T),]

# non-cancer
drugNames_category=onTarget$drugCategory[match(drugNames$TP53, onTarget$drugCategory$name),]
drugNames$TP53
drugNames_category$name[drugNames_category$drug_category=='noncancer']

######################################################
# Plot # of mutant selecting drugs
######################################################
df2plot=data.frame(cancer_genes=freqMut_cancerGenes, Drugs=0)
df2plot$Drugs[df2plot$cancer_genes=='TP53']=58
df2plot$Drugs[df2plot$cancer_genes=='KRAS']=6
df2plot$Drugs[df2plot$cancer_genes=='RB1']=1
df2plot$Drugs[df2plot$cancer_genes=='PTEN']=1
df2plot$Drugs[df2plot$cancer_genes=='PIK3CA']=1

tiff('/Users/sinhas8/Project_Drugs_selelecting_Driver_mutations/mutant_selecting_drugs.tiff',
     width = 600, height=400)
ggplot(df2plot, aes(x=reorder(cancer_genes, -Drugs), y=Drugs))+
  geom_bar(stat='identity')+
  theme_bw(base_size = 16)+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  labs(x='Major cancer driver genes', y='# drugs selecting \nmutant cells (FDR<0.1)')
dev.off()

