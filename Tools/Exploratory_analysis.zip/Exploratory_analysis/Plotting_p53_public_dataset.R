###Public_p53
################################################################
##CRSIPR
################################################################
setwd('/Users/sinhas8/Project_CRISPR/Project_CRISPR_bias/Tools/')
source('Globally_used_Functions_and_Datasets.R')
Mut_R1=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/Isogenic_Screenings/Genome wide screening data RPE/R1-null.gene_summary.txt', sep='\t')
Mut_R2=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/Isogenic_Screenings/Genome wide screening data RPE/R2-null.gene_summary.txt', sep='\t')
WT_R1=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/Isogenic_Screenings/Genome wide screening data RPE/R1-WT.gene_summary.txt', sep='\t')
WT_R2=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/Isogenic_Screenings/Genome wide screening data RPE/R2-WT.gene_summary.txt', sep='\t')
CDE=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/CDE_allThree.csv')
WT_R1=WT_R1[!is.na(match(as.character(unlist(WT_R1$id)), rownames(onTarget$avana))), ]
WT_R2=WT_R2[!is.na(match(as.character(unlist(WT_R2$id)), rownames(onTarget$avana))), ]
Mut_R1=Mut_R1[!is.na(match(as.character(unlist(Mut_R1$id)), rownames(onTarget$avana))), ]
Mut_R2=Mut_R2[!is.na(match(as.character(unlist(Mut_R2$id)), rownames(onTarget$avana))), ]
Mut_R2=Mut_R2[match(Mut_R1$id, Mut_R2$id),]
Mut_avgLFC=data.frame(geneName=Mut_R2$id,
                      avgLFC=rowMeans(data.frame(Mut_R2$neg.lfc,
                                                 Mut_R1$neg.lfc )),
                      RRA.pos=rowMeans(data.frame(Mut_R2$pos.rank,
                                                  Mut_R1$pos.rank)),
                      RRA.neg=rowMeans(data.frame(Mut_R2$neg.rank,
                                                  Mut_R1$neg.rank)))
WT_R2 = WT_R2[match(WT_R1$id, WT_R2$id),]
WT_avgLFC=data.frame(geneName=WT_R2$id, 
                     avgLFC=rowMeans(data.frame(WT_R2$neg.lfc, WT_R1$neg.lfc)),
                     RRA.pos=rowMeans(data.frame(WT_R2$pos.rank,
                                                 WT_R1$pos.rank)),
                     RRA.neg=rowMeans(data.frame(WT_R2$neg.rank,
                                                 WT_R1$neg.rank)))
WT_avgLFC=WT_avgLFC[match(Mut_avgLFC$geneName, WT_avgLFC$geneName),]
df_p53Haap=data.frame(WT_avgLFC, Mut=Mut_avgLFC)
df_p53Haap$Rank_WT=rank(df_p53Haap$avgLFC)
df_p53Haap$Rank_Mut=rank(df_p53Haap$Mut.avgLFC)
################################################################
###RNAi analysis for p53
################################################################
emsemblmapping=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/mart_export.txt', sep='\t')
df_p53=read.csv('/Users/sinhas8/Project_CRISPR/2.Data/Isogenic_Screenings/p53_isogenic_shRNA_screening.csv')
df_p53$Gene_Symbol=emsemblmapping$Gene.name[match(df_p53$Ensemble, emsemblmapping$Gene.stable.ID)]
df_p53=na.omit(df_p53)
df_p53$GeneType=NA

df_p53$Mut.log2.Mean=rowMeans(df_p53[,c("z..KO.A.","z..KO.B.")])
df_p53$WT.log2.Mean=rowMeans(df_p53[,c("z...WT.A.","z..WT.B.")])
df_p53$Rank_WT=rank(df_p53$WT.log2.Mean)
df_p53$Rank_Mut=rank(df_p53$Mut.log2.Mean)

##Test for Top X
CDE=read.csv('Data/CDEs_of_ThreeMaster_Regulators.csv')
CDE=lapply(CDE, function(x) as.character(x[x!='']) )
CDE$P53.CDE.Pos=head(CDE$P53.CDE.Pos, 15)
df_p53Haap$GeneType=NA
df_p53Haap$GeneType[!is.na(match(df_p53Haap$geneName, CDE$P53.CDE.Pos))]='p53 CDE Pos'
df_p53Haap$GeneType[!is.na(match(df_p53Haap$geneName, CDE$P53.CDE.Neg))]='p53 CDE Neg'
df_p53Haap$GeneType[!(!is.na(match(df_p53Haap$geneName, CDE$P53.CDE.Pos)) |
                        !is.na(match(df_p53Haap$geneName, CDE$P53.CDE.Neg))) ]='p53 CDE Neutral'
table(df_p53Haap$GeneType)

df_p53$GeneType[!is.na(match(df_p53$Gene_Symbol, CDE$P53.CDE.Pos))]='p53 CDE Pos'
df_p53$GeneType[!is.na(match(df_p53$Gene_Symbol, CDE$P53.CDE.Neg))]='p53 CDE Neg'
df_p53$GeneType[!(!is.na(match(df_p53$Gene_Symbol, CDE$P53.CDE.Pos)) |
                    !is.na(match(df_p53$Gene_Symbol, CDE$P53.CDE.Neg))) ]='p53 CDE Neutral'
table(df_p53$GeneType)
################################################################
###Plot
################################################################
cde_type='p53 CDE Pos'
which_tail='l'
FC_inMutant_crispr=df_p53Haap$Mut.RRA.pos[df_p53Haap$GeneType==cde_type]
FC_inWT_crispr=df_p53Haap$RRA.pos[df_p53Haap$GeneType==cde_type]
FC_inMutant_shRNA=df_p53$Rank_Mut[df_p53$GeneType==cde_type]
FC_inWT_shRNA=df_p53$Rank_WT[df_p53$GeneType==cde_type]

df2plot=rbind(
  data.frame(FC_change=FC_inMutant_shRNA, MR='p53-Mut', Method='shRNA', Type='CDE+'),
  data.frame(FC_change=FC_inWT_shRNA, MR='p53-WT', Method='shRNA', Type='CDE+')
  ,data.frame(FC_change=FC_inMutant_crispr, MR='p53-Mut', Method='CRISPR-Cas9', Type='CDE+'),
  data.frame(FC_change=FC_inWT_crispr, MR='p53-WT', Method='CRISPR-Cas9', Type='CDE+')
  # ,data.frame(FC_change=FC_inMutant_crispr2, MR='KRAS-Mut', Method='CRISPR-Cas9', Type='CDE+'),
  # data.frame(FC_change=FC_inWT_crispr2, MR='KRAS-WT', Method='CRISPR-Cas9', Type='CDE+')
)
df2plot$MR=factor(df2plot$MR, levels = rev(levels(df2plot$MR)))
tiff('Plots/Publicly_available_dataSet_p53.tiff')  
ggplot(df2plot, aes(y=FC_change, fill=MR, x=Method))+
  geom_boxplot(outlier.shape = NA)+
  facet_wrap(.~Type)+
  stat_compare_means(label = 'p', method.args = list(alternative=which_tail),
                     paired=T, method='wilcox', size=7)+
  theme_classic(base_size = 25)+
  theme(legend.position = 'top', legend.title = element_blank(), legend.key.size = unit(3, "lines"))+
  labs(x='Method', y='Cell Viability after KO')+
  scale_fill_manual(values = c('grey', 'indianred2'))
dev.off()  

