# # Identify drug_transcriptomic response 
require(lsa); require(matrixStats); library(cmapR); library(data.table)
source('/Users/sinhas8/myCustom_functions.R')
setwd('/Users/sinhas8/Project_OffTarget/2.Data/PhaseII_20180410/')
load("siginfo.RData")
# signature IDs for vorinostat
laura_list=readxl::read_xlsx('/Users/sinhas8/Downloads/updated list_validated 1&2-5uM.xlsx')
drugList=tolower(unique(laura_list$Name))
drugList_id=sapply(tolower(siginfo$pert_iname), function(x) grep(x, drugList))
sig.ids <- na.omit(siginfo[sapply(drugList_id, length)>0, sig_id])
# read from the gctx file
sigs <- parse_gctx("GSE70138_Broad_LINCS_Level5_COMPZ_n118050x12328_2017-03-06.gctx",
                   cid=sig.ids)
load('/Users/sinhas8/Project_OffTarget/2.Data/PhaseII_20180410/geneinfo.RData')
rownames(sigs@mat)=as.character(geneinfo$pr_gene_symbol)
mat_list=split.data.frame(t(sigs@mat), names(drugList_id[sapply(drugList_id, length)>0]))
mat=sapply(mat_list, function(x)  rowMedians(apply(t(x), 2, scale)) )
rownames(mat)=as.character(geneinfo$pr_gene_symbol)

# Identify the signature
sumit_exp=read.csv('/Users/sinhas8/Downloads/tpm.filtered.tsv', sep='\t')
lfc_df=t(apply(sumit_exp, 1, function(x) c(wilcox.test(x[1:3], x[4:6])$p.value,
                                           log((median(x[4:6]+0.1)/median(x[1:3]+0.1))+1, base = 2) ) ))

colnames(lfc_df)=c('pvalue', 'lfc')
lfc_df_mapped=lfc_df[match(rownames(mat), rownames(lfc_df)),]
mat_wdLFC=cbind(lfc_df_mapped, mat)
mat_wdLFC=na.omit(mat_wdLFC)
# Overall Gene Signature
which_sig=which(mat_wdLFC[,1]<0.1)

cosin_score=cosine(mat_wdLFC[which_sig,])[2,-c(1:2)]
cosin_score[order(cosin_score, decreasing = T)]

# Control
randomize<-function(pp=1) {
  mat_wdLFC_rand=cbind(lfc_df_mapped, t(apply(mat, 1, sample)))
  mat_wdLFC_rand=na.omit(mat_wdLFC_rand)
  # Overall Gene Signature
  which_sig_rand=which(mat_wdLFC_rand[,1]<0.1)
  length(which_sig_rand)
  cosin_score_rand=cosine(mat_wdLFC_rand[which_sig_rand,])[2,-c(1:2)]
  sum(cosin_score_rand[order(cosin_score_rand, decreasing = T)]>0.2)>0
}
  p_value=sum(!sapply(1:100, randomize))/100







# Only for Viral genes
viralGenes_GO=read.csv('/Users/sinhas8/Downloads/viral_geneset.txt')
viralGenes_GO_id=na.omit(match(as.character(viralGenes_GO$RESPONSE_TO_VIRUS), rownames(mat_wdLFC)))
cosine(mat_wdLFC[viralGenes_GO_id,])[2,-c(1:2)]


