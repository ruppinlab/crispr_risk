# Chemo pre/post TV
compd3=readxl::read_xlsx('/Users/sinhas8/Comptetion_p53_wtvsnull_chemo_andrew.xlsx',
                         sheet = 1)
compd3=cbind(compd3, day='day3')
compd5=readxl::read_xlsx('/Users/sinhas8/Comptetion_p53_wtvsnull_chemo_andrew.xlsx',
                         sheet = 2)
compd5=cbind(compd5, day='day5')
compd7=readxl::read_xlsx('/Users/sinhas8/Comptetion_p53_wtvsnull_chemo_andrew.xlsx',
                         sheet = 3)
compd7=cbind(compd7, day='day7')
compd9=readxl::read_xlsx('/Users/sinhas8/Comptetion_p53_wtvsnull_chemo_andrew.xlsx',
                         sheet = 4)
compd9=cbind(compd9, day='day9')
comp=rbind(compd3, compd5, compd7, compd9)
comp$mean_change=rowMeans(data.frame(comp$`WT-FF:KO-Renilla`,
                                     comp$`WT-Renilla:KO-FF`))
require(ggplot2)
tiff('/Users/sinhas8/Project_CRISPR/comp_by_dose.tiff', width = 900)
ggplot(comp[comp$day=='day9',], aes(y=10^(mean_change),
                 x=factor(DrugName_with_Dosage)))+
  geom_boxplot()+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))+
  labs(y='FC(p53 WT/Null)', 'x=Drugs')+
  geom_hline(yintercept = 1, color='red', linetype='dashed')
dev.off()  


# Our p53 CDEs
tiff('/Users/sinhas8/Project_CRISPR/CDE_comp.tiff', width = 900, height=900)
p53cde_comp=readxl::read_xlsx('/Users/sinhas8/Downloads/KRAS_P53_competition3for Sanju (2).xlsx')
ggplot(p53cde_comp, aes(x=factor(Timepoint), y=TdTomato))+
  geom_boxplot()+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))+
  labs(y='FC(p53 WT/Null)', 'x=Drugs')+
  facet_wrap(~Gene)
dev.off()

p53cde_comp$FC=p53cde_comp$TdTomato/(100-p53cde_comp$TdTomato)
lapply(split(p53cde_comp, p53cde_comp$Timepoint), )
genelevel_p53cde_comp=aggregate(TdTomato ~Gene+Timepoint, data = p53cde_comp, function(x) mean(x))
genelevel_p53cde_comp$FC=genelevel_p53cde_comp$TdTomato/(100-genelevel_p53cde_comp$TdTomato)

genelevel_p53cde_compDiff=data.frame(Gene=genelevel_p53cde_comp$Gene[genelevel_p53cde_comp$Timepoint==0],
                                     FC_diff=genelevel_p53cde_comp$FC[genelevel_p53cde_comp$Timepoint==15] -
                                       genelevel_p53cde_comp$FC[genelevel_p53cde_comp$Timepoint==0])
tiff('/Users/sinhas8/Project_CRISPR/CDE_FC_compDifference.tiff', width = 600, height=600)
ggplot(genelevel_p53cde_compDiff, aes(x=factor(Gene), y=FC_diff))+
  geom_boxplot()+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 90, hjust = 1))+
  labs(y='FC(p53 Mut)', 'x=Gene')+
  geom_hline(yintercept = 0)
dev.off()

