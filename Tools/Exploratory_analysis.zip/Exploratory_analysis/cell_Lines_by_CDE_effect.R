################################################################
# Rank each cell line based on their CDE+ effect
################################################################
source('/Users/sinhas8/crispr_risk-master/Tools/Step0_Globally_used_Functions_and_Datasets.R')
COI=Reduce(intersect, list(colnames(avana),
                           colnames(achilles),
                           colnames(Mut_CCLE)))
GOI=Reduce(intersect, list(rownames(avana),
                           rownames(achilles)))
p53=Mut_CCLE['TP53',COI]
p53=as.numeric(p53>0)
kras=Mut_CCLE['KRAS',COI]
kras=as.numeric(kras>0)
df2plot=rbind(data.frame(geneMedianEss=apply(avana[GOI,COI[p53==1]], 2, median),
                         p53='Mut', screen='crispr'),
              data.frame(geneMedianEss=apply(avana[GOI,COI[p53==0]], 2, median),
                         p53='WT', screen='crispr'),
              data.frame(geneMedianEss=apply(achilles[GOI,COI[p53==1]], 2,
                                             function(x) median(x, na.rm = T)),
                         p53='Mut', screen='shRNA'),
              data.frame(geneMedianEss=apply(achilles[GOI,COI[p53==0]], 2,
                                             function(x) median(x, na.rm = T)),
                         p53='WT', screen='shRNA'))


tiff('/Users/sinhas8/Project_CRISPR/p53MutvsWT_indiffScreens_correctedv2.tiff',
     width = 400, height= 400)
ggplot(df2plot, aes(y=geneMedianEss, x=p53, fill=p53))+
  geom_boxplot()+
  facet_wrap(screen ~.)+
  stat_compare_means(method='wilcox', label = 'p')+
  theme_bw(base_size = 20)+
  labs(y="Median viability\nafter a gene silencing")
dev.off()

tiff('/Users/sinhas8/Project_CRISPR/p53MutvsWT_indiffScreens_correctedv2_ourCDE.tiff',
     width = 400, height= 400)
ggplot(df2plot, aes(y=geneMedianEss, x=p53, fill=p53))+
  geom_boxplot()+
  facet_wrap(screen ~.)+
  stat_compare_means(method='wilcox', label = 'p')+
  theme_bw(base_size = 20)+
  labs(y="Median viability\nafter a gene silencing")
dev.off()
################################################################
# Rank each cell line based on their CDE+ effect
################################################################
df2plot=data.frame(cde_median_essentiality_crispr=apply(avana[,COI],
                                                        2, function(x) median(x)),
                   cde_median_essentiality_shRNA=apply(achilles[,COI],
                                                       2, function(x) median(x, na.rm = T)),
                   p53,
                   kras)
scaled_avana=apply(avana[GOI,COI], 1, scale)
scaled_achilles=apply(achilles[GOI,COI], 1, scale)
diff_matrix=scaled_avana - scaled_achilles
df2plot$diff_corrected = apply(diff_matrix, 1, function(x) median(x, na.rm = T))
df2plot$avana_median = apply(scaled_avana, 1, function(x) median(x, na.rm = T))
df2plot$achilles_median = apply(scaled_achilles, 1, function(x) median(x, na.rm = T))
a549_id=grep('A549',rownames(df2plot))
df2plot$label=''
df2plot$label[a549_id]='A549'
bottom_five_id=head(order(df2plot$diff_corrected), 5)
top_five_id=head(order(df2plot$diff_corrected, decreasing = T), 5)
df2plot$label[bottom_five_id]=rownames(df2plot)[bottom_five_id]
df2plot$label[top_five_id]=rownames(df2plot)[top_five_id]
df2plot=na.omit(df2plot)
df2plot$p53=factor(df2plot$p53>0, labels = c('WT', 'Mut'))
df2plot$kras=factor(df2plot$kras>0, labels = c('WT', 'Mut'))
df2plot$size=ifelse(df2plot$label=='A549', 3, 2)
df2plot=df2plot[order(df2plot$diff_corrected, decreasing = T),]
# Send to Moshe
df2send=df2plot[,c(3, 4, 8, 6)]
colnames(df2send)=c('p53 Mutation Status',
                    'kras Mutation Status',
                    'Cell Lines of Interest',
                    'Viability difference (CRISPR-shRNA) [Corrected]')
write.table(df2send,
            '/Users/sinhas8/Project_CRISPR/List of ranked CCLE CellLines by CRISPR specific Selection.csv',
            sep = ',')


tiff('/Users/sinhas8/Project_CRISPR/cell_Line_Ranking_correctedv2.tiff',
     width = 600, height= 500)
ggplot(df2plot, aes(y=diff_corrected,x=reorder(1:nrow(df2plot), diff_corrected),
                    label=label, fill=p53))+
  geom_point(aes(color=p53, size=size))+
  geom_label_repel()+
  guides(size = FALSE)+
  labs(y='Median (CRISPR - shRNA) viability\n across all the genes',
       x='CCLE Cell Lines (n=382)')+
  theme_bw(base_size = 15)+
  geom_hline(yintercept =0, linetype='dotted')+
  theme(legend.position = 'top',
        axis.text.x=element_blank())
dev.off()
################################################################
# Rank each cell line based on their CDE+ effect:: KRAS
################################################################
COI=Reduce(intersect, list(colnames(avana),
                           colnames(achilles),
                           colnames(Mut_CCLE)))
GOI=Reduce(intersect, list(rownames(avana),
                           rownames(achilles)))
p53=Mut_CCLE['TP53',COI]
COI=COI[p53==1]
kras=Mut_CCLE['KRAS',COI]
df2plot=rbind(data.frame(geneMedianEss=apply(avana[GOI,COI[kras==1]], 2, median),
                         kras='Mut', screen='crispr'),
              data.frame(geneMedianEss=apply(avana[GOI,COI[kras==0]], 2, median),
                         kras='WT', screen='crispr'),
              data.frame(geneMedianEss=apply(achilles[GOI,COI[kras==1]], 2,
                                             function(x) median(x, na.rm = T)),
                         kras='Mut', screen='shRNA'),
              data.frame(geneMedianEss=apply(achilles[GOI,COI[kras==0]], 2,
                                             function(x) median(x, na.rm = T)),
                         kras='WT', screen='shRNA'))

tiff('/Users/sinhas8/Project_CRISPR/krasMutvsWT_p53MutantCellLines_indiffScreens_correctedv2.tiff',
     width = 400, height= 400)
ggplot(df2plot, aes(y=geneMedianEss, x=kras, fill=kras))+
  geom_boxplot()+
  facet_wrap(screen ~.)+
  # geom_text(data=p_df, aes(y=0.055,x=1.5,label=paste('p =',p_value)))+
  stat_compare_means(method='wilcox', label = 'p')+
  theme_bw(base_size = 20)+
  labs(y="Median viability after\na CDE+ gene silencing")
dev.off()

tiff('/Users/sinhas8/Project_CRISPR/krasMutvsWT_p53MutantCellLines__indiffScreens_correctedv2_ourCDE.tiff',
     width = 400, height= 400)
ggplot(df2plot, aes(y=geneMedianEss, x=kras, fill=kras))+
  geom_boxplot()+
  facet_wrap(screen ~.)+
  stat_compare_means(method='wilcox', label = 'p')+
  theme_bw(base_size = 20)+
  labs(y="Median viability after\nCDE+ genes silencing")
dev.off()



