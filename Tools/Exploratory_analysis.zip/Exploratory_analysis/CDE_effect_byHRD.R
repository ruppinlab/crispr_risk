# Test CDE effect in HRD subset of cell lines
setwd('/Users/sinhas8/Project_CRISPR/Project_CRISPR.Risk_Github/')
source('Tools/Step0_Globally_used_Functions_and_Datasets.R')

####################################################################################
##Identifying the DE, CDE genes for TP53 gene
####################################################################################
## This function return four a list of DE+/- for a given master regulator in shrna 
## and crispr with effect size.
GOI=DDR_Geneset_List$Damage.Sensor.etc.
hrd= as.logical(colSums(Mut_CCLE[
  na.omit(match(GOI, rownames(Mut_CCLE))),]))
p53_DE_hrd=Testing_CRISPR_damage_bias(GeneName='TP53',
                                  Feature_to_test=Mut_CCLE[,hrd], 
                                  base_dataset=avana[,hrd], 
                                  reference_dataset=achilles[,hrd],
                                  confounding_variable_dataset=CNV[,hrd], 
                                  cores2use=detectCores())
p53_DE_hrd=Testing_CRISPR_damage_bias(GeneName='TP53',
                                      Feature_to_test=Mut_CCLE[,sample(which(!hrd), 89)], 
                                      base_dataset=avana[,sample(which(!hrd), 89)],
                                      reference_dataset=achilles[,sample(which(!hrd), 89)],
                                      confounding_variable_dataset=CNV[,sample(which(!hrd), 89)],
                                      cores2use=detectCores())

##Identifying the size of DE genes
#Size of CRISPR DE+ genes
print(paste('Size of CRISPR DE+ genes', nrow(p53_DE$CRISPR_DE_pos)))
#Size of CRISPR DE- genes
print(paste('Size of CRISPR DE- genes', nrow(p53_DE$CRISPR_DE_neg)))
#Size of shrna DE+ genes
print(paste('Size of shrna DE+ genes', nrow(p53_DE$shrna_DE_pos)))
#Size of shrna DE- genes
print(paste('Size of shrna DE- genes', nrow(p53_DE$shrna_DE_neg)))

###Following are the CDE+ and CDE- genes of p53 genes 
p53_CDE_pos= p53_DE$CRISPR_DE_pos$GeneName[p53_DE$CRISPR_DE_pos$GeneName %!in% p53_DE$shrna_DE_pos$GeneName]
p53_CDE_neg= p53_DE$CRISPR_DE_neg$GeneName[p53_DE$CRISPR_DE_neg$GeneName %!in% p53_DE$shrna_DE_neg$GeneName]

##Identifying the size of CDE (CRISPR-specific DE) genes
length(p53_CDE_pos)
length(p53_CDE_neg)
####################################################################################
##Calculating the probability of imbalance of DE+/- in crispr  in comparison to control (shrna)
####################################################################################
p53_Contigency=t(sapply(p53_DE, nrow))
p53_DE_imbalance_prob=significance_test(p53_Contigency)
####################################################################################
## Using the above framework, we'd identify DE+/- genes for cancer driver genes defined
## in Vogestein et al.
####################################################################################
Vog_Gene_df=get(load('Data/vogelstein.RData'))
Vog_Genes=Vog_Gene_df$symbol
Vog_Genes=c('TP53', 'KRAS', 'VHL')
mat= lapply(Vog_Genes, function(x) Testing_CRISPR_damage_bias(GeneName=x))
saveRDS(mat, 'Data/Volg_CDE.RDS')
###To quickly repliacte, in substitute, one can load Volg_DE genes for each 
##mat=readRDS('/cbcbhomes/sanju/Volg_CDE.RDS')
Contigency=t(sapply(mat, function(x) sapply(x, nrow)))
Sig=p.adjust(unlist(apply(Contigency, 1, function(x)  significance_test(x))), method='fdr')
Log_Sig=-log(Sig, 10)
Log_Sig_df=data.frame(Vog_Cand, Log_Sig)
Log_Sig_df=Log_Sig_df[order(Log_Sig_df$Log_Sig),]
Log_Sig_df$Log_Sig[Log_Sig_df$Log_Sig>300]=300
####################################################################################
##Using CDE genes positive and negative to identify the Master Regualtors
####################################################################################
##Variable comprising saved CDE genes for each genes
CDE=readRDS('Data/CDE_for_volg.RDS')
CDE_pos_size=sapply(CDE, function(x) length(x[[1]]))
Log_Sig_df$CDE_pos=CDE_pos_size[match(Log_Sig_df$Vog_Cand, names(CDE_pos_size))]
Log_Sig_df$col=''
Log_Sig_df$col[Log_Sig_df$CDE_pos>100]='Hits of Interest'

##plotting CDEsize vs significance
plot1=ggplot(Log_Sig_df, aes(x=Log_Sig, y=CDE_pos, color=col))+
  geom_point(aes(size=ifelse(CDE_pos>1 | Log_Sig>50 , 3, 2)))+
  labs(x=expression(-log[10](p)), y='Number of Genes\nat Significant Risk')+
  geom_text_repel(
    data = subset(Log_Sig_df, CDE_pos > 1 | Log_Sig>50 ), nudge_y=100,
    aes(label = Vog_Cand),
    box.padding = unit(0.35, "lines"),
    point.padding = unit(0.3, "lines")
  )+
  scale_color_manual(values=c("black", "#56B4E9"), guide=FALSE)+theme_classic()+scale_size(guide = 'none')
plot2 <- ggplot(Log_Sig_df, aes(Log_Sig)) + 
  geom_density(alpha=.5)+theme_classic()+
  labs(x=expression(-log[10](p)), y='Density')

joined_plot=grid.arrange(plot2, plot1, 
                         ncol=1, nrow=2, heights=c(1,3))
pdf('/cbcbhomes/sanju/vog_Sig_4th_part2.pdf', 10, 4)
plot(joined_plot)
dev.off()
